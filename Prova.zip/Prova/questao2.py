numeroi = int(input("Digite um número inteiro: "))
       
if numeroi < 0:
    print("Retroceder") 

elif numeroi == 0:
    print ("pare")

else:
    print ("Avançar") 



